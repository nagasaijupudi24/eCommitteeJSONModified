/* eslint-disable @typescript-eslint/no-explicit-any */
export interface IPDFViewerProps {
    pdfPath: string;
    zoomLevel?: number;
    noteNumber:any;
  }
  