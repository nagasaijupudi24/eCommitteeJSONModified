/* tslint:disable */
require("./PasscodeModal.module.css");
const styles = {
  passcodeModalContainer: 'passcodeModalContainer_e26c3456',
  header: 'header_e26c3456',
  closeButton: 'closeButton_e26c3456',
  body: 'body_e26c3456',
  buttons: 'buttons_e26c3456'
};

export default styles;
/* tslint:enable */